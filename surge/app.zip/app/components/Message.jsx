const Message = ({ msg }) => {
  return (
    <div>
      Hallo dit was het bericht: <br />
      {msg}
    </div>
  );
};

export default Message;
